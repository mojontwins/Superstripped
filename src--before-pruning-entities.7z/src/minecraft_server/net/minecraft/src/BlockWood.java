package net.minecraft.src;

import java.util.List;

public class BlockWood extends Block {
	public BlockWood(int i1) {
		super(i1, 4, Material.wood);
		
		this.displayOnCreativeTab = CreativeTabs.tabBlock;
	}

	public int getBlockTextureFromSideAndMetadata(int i1, int i2) {
		switch(i2) {
		case 1:
			return 198;
		case 2:
			return 214;
		case 3:
			return 199;
		default:
			return 4;
		}
	}

	public int damageDropped(int i1) {
		return i1;
	}
	
	public void getSubBlocks(int par1, CreativeTabs par2CreativeTabs, List<ItemStack> par3List) {
		par3List.add(new ItemStack(par1, 1, 0));
		if(SoftLock.level < SoftLock.BETA) return;
		par3List.add(new ItemStack(par1, 1, 1));
		par3List.add(new ItemStack(par1, 1, 2));
		if(SoftLock.level < SoftLock.R125) return;
		par3List.add(new ItemStack(par1, 1, 3));
	}
}
