package net.minecraft.src;

public abstract class EntityWeatherEffect extends Entity {
	public EntityWeatherEffect(World world1) {
		super(world1);
	}
}
