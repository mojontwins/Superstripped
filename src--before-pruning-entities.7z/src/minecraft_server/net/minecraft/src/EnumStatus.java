package net.minecraft.src;

public enum EnumStatus {
	OK,
	NOT_POSSIBLE_HERE,
	NOT_POSSIBLE_NOW,
	TOO_FAR_AWAY,
	OTHER_PROBLEM,
	NOT_SAFE;
}
