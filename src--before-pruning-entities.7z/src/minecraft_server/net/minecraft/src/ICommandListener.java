package net.minecraft.src;

public interface ICommandListener {
	void log(String string1);

	String getUsername();
}
