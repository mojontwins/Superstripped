package net.minecraft.src;

interface IEnchantmentModifier {
	void calculateModifier(Enchantment enchantment1, int i2);
}
