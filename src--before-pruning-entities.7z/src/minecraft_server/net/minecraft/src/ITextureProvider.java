package net.minecraft.src;

public interface ITextureProvider {
	String getTextureFile();
}
