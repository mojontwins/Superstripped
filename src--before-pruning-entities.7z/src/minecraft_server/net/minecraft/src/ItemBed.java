package net.minecraft.src;

public class ItemBed extends Item {
	public ItemBed(int i1) {
		super(i1);
		this.displayOnCreativeTab = CreativeTabs.tabDeco;
	}

	public boolean onItemUse(ItemStack itemStack1, EntityPlayer entityPlayer2, World world3, int i4, int i5, int i6, int i7) {
		return false;	}

	public boolean validBlockBeneath(World world, int x, int y, int z) {
		if(world.isAirBlock(x, y, z)) return false;
		if(world.isBlockNormalCube(x, y, z)) return true;
		int blockID = world.getBlockId(x, y, z);
		if(blockID == Block.stairSingle.blockID) return (world.getBlockMetadata(x, y, z) & 8) != 0;
		Block block = Block.blocksList[blockID];
		if(block instanceof BlockStairs) return (world.getBlockMetadata(x, y, z) & 4) != 0;
		return false;
	}
}
