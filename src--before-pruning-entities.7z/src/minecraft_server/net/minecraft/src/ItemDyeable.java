package net.minecraft.src;

public class ItemDyeable extends ItemBlock {
	public ItemDyeable(int i1) {
		super(i1);
		this.setMaxDamage(0);
		this.setHasSubtypes(true);
	}

	public int getIconFromDamage(int i1) {
		return Block.cloth.getBlockTextureFromSideAndMetadata(2, BlockCloth.getMetadataFromDye(i1));
	}

	public int getMetadata(int i1) {
		return i1;
	}

	public String getItemNameIS(ItemStack itemStack1) {
		return super.getItemName() + "." + ItemDye.dyeColorNames[BlockCloth.getMetadataFromDye(itemStack1.getItemDamage())];
	}
}
