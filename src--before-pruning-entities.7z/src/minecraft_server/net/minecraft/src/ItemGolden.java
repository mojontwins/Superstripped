package net.minecraft.src;

public class ItemGolden extends Item {

	public ItemGolden(int i1) {
		super(i1);
	}

}
