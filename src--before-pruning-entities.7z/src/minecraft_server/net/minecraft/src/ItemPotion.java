package net.minecraft.src;

import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class ItemPotion extends Item {
	private HashMap<Integer, List<PotionEffect>> effectCache = new HashMap<Integer, List<PotionEffect>>();
	private static final Map<List<PotionEffect>,Integer> potionEffectsHashmap = new LinkedHashMap<List<PotionEffect>,Integer>();

	public ItemPotion(int i1) {
		super(i1);
		this.setMaxStackSize(1);
		this.setHasSubtypes(true);
		this.setMaxDamage(0);
		
		this.displayOnCreativeTab = CreativeTabs.tabBrewing;
	}

	public List<PotionEffect> getEffects(ItemStack itemStack1) {
		return this.getEffects(itemStack1.getItemDamage());
	}

	public List<PotionEffect> getEffects(int i1) {
		List<PotionEffect> list2 = (List<PotionEffect>)this.effectCache.get(i1);
		if(list2 == null) {
			list2 = PotionHelper.getPotionEffects(i1, false);
			this.effectCache.put(i1, list2);
		}

		return list2;
	}

	public ItemStack onFoodEaten(ItemStack itemStack1, World world2, EntityPlayer entityPlayer3) {
		--itemStack1.stackSize;
		if(!world2.isRemote) {
			List<?> list4 = this.getEffects(itemStack1);
			if(list4 != null) {
				Iterator<?> iterator5 = list4.iterator();

				while(iterator5.hasNext()) {
					PotionEffect potionEffect6 = (PotionEffect)iterator5.next();
					entityPlayer3.addPotionEffect(new PotionEffect(potionEffect6));
				}
			}
		}

		if(itemStack1.stackSize <= 0) {
			return new ItemStack(Item.glassBottle);
		} else {
			entityPlayer3.inventory.addItemStackToInventory(new ItemStack(Item.glassBottle));
			return itemStack1;
		}
	}

	public int getMaxItemUseDuration(ItemStack itemStack1) {
		return 32;
	}

	public EnumAction getItemUseAction(ItemStack itemStack1) {
		return EnumAction.drink;
	}

	public ItemStack onItemRightClick(ItemStack itemStack1, World world2, EntityPlayer entityPlayer3) {
		if(isSplash(itemStack1.getItemDamage())) {
			--itemStack1.stackSize;
			world2.playSoundAtEntity(entityPlayer3, "random.bow", 0.5F, 0.4F / (itemRand.nextFloat() * 0.4F + 0.8F));
			if(!world2.isRemote) {
				world2.spawnEntityInWorld(new EntityPotion(world2, entityPlayer3, itemStack1.getItemDamage()));
			}

			return itemStack1;
		} else {
			entityPlayer3.setItemInUse(itemStack1, this.getMaxItemUseDuration(itemStack1));
			return itemStack1;
		}
	}

	public boolean onItemUse(ItemStack itemStack1, EntityPlayer entityPlayer2, World world3, int i4, int i5, int i6, int i7) {
		return false;
	}

	public int getIconFromDamage(int i1) {
		return isSplash(i1) ? 154 : 140;
	}

	public int getIconFromDamageAndRenderpass(int i1, int i2) {
		return i2 == 0 ? 141 : super.getIconFromDamageAndRenderpass(i1, i2);
	}

	public static boolean isSplash(int i0) {
		return (i0 & 16384) != 0;
	}

	public int getColorFromDamage(int i1, int i2) {
		return i2 > 0 ? 0xFFFFFF : PotionHelper.func_40358_a(i1, false);
	}

	public boolean requiresMultipleRenderPasses() {
		return true;
	}

	public boolean isEffectInstant(int i1) {
		List<PotionEffect> list2 = this.getEffects(i1);
		if(list2 != null && !list2.isEmpty()) {
			Iterator<PotionEffect> iterator3 = list2.iterator();

			PotionEffect potionEffect4;
			do {
				if(!iterator3.hasNext()) {
					return false;
				}

				potionEffect4 = (PotionEffect)iterator3.next();
			} while(!Potion.potionTypes[potionEffect4.getPotionID()].isInstant());

			return true;
		} else {
			return false;
		}
	}

	public String getItemDisplayName(ItemStack itemStack1) {
		if(itemStack1.getItemDamage() == 0) {
			return Translator.translateToLocal("item.emptyPotion.name").trim();
		} else {
			String string2 = "";
			if(isSplash(itemStack1.getItemDamage())) {
				string2 = Translator.translateToLocal("potion.prefix.grenade").trim() + " ";
			}

			List<?> list3 = Item.potion.getEffects(itemStack1);
			String string4;
			if(list3 != null && !list3.isEmpty()) {
				string4 = ((PotionEffect)list3.get(0)).getEffectName();
				string4 = string4 + ".postfix";
				return string2 + Translator.translateToLocal(string4).trim();
			} else {
				string4 = PotionHelper.func_40359_b(itemStack1.getItemDamage());
				return Translator.translateToLocal(string4).trim() + " " + super.getItemDisplayName(itemStack1);
			}
		}
	}

	public void addInformation(ItemStack itemStack1, List<String> list2) {
		if(itemStack1.getItemDamage() != 0) {
			List<PotionEffect> list3 = Item.potion.getEffects(itemStack1);
			if(list3 != null && !list3.isEmpty()) {
				Iterator<PotionEffect> iterator7 = list3.iterator();

				while(iterator7.hasNext()) {
					PotionEffect potionEffect5 = (PotionEffect)iterator7.next();
					String string6 = Translator.translateToLocal(potionEffect5.getEffectName()).trim();
					if(potionEffect5.getAmplifier() > 0) {
						string6 = string6 + " " + Translator.translateToLocal("potion.potency." + potionEffect5.getAmplifier()).trim();
					}

					if(potionEffect5.getDuration() > 20) {
						string6 = string6 + " (" + Potion.getDurationString(potionEffect5) + ")";
					}

					if(Potion.potionTypes[potionEffect5.getPotionID()].isBadEffect()) {
						list2.add("\u00a7c" + string6);
					} else {
						list2.add("\u00a77" + string6);
					}
				}
			} else {
				String string4 = Translator.translateToLocal("potion.empty").trim();
				list2.add("\u00a77" + string4);
			}

		}
	}

	public boolean hasEffect(ItemStack itemStack1) {
		List<?> list2 = this.getEffects(itemStack1);
		return list2 != null && !list2.isEmpty();
	}
	
	public void getSubItems(int par1, CreativeTabs par2CreativeTabs, List<ItemStack> par3List) {
		super.getSubItems(par1, par2CreativeTabs, par3List);
		
		if(potionEffectsHashmap.isEmpty()) {
			for(int i = 0; i < 32767; i ++) {
				List<PotionEffect> potionEffectsForInt = PotionHelper.getPotionEffects(i, false);
				if(potionEffectsForInt != null && !potionEffectsForInt.isEmpty()) {
					potionEffectsHashmap.put(potionEffectsForInt, Integer.valueOf(i));
				}
			}
		}
		
		Iterator<Integer> iterator = potionEffectsHashmap.values().iterator();
		while(iterator.hasNext()) {
			par3List.add(new ItemStack(par1, 1, iterator.next().intValue()));
		}
	}
}
