package net.minecraft.src;

public class SoftLock {
	public static final int ALPHA_EARLY = 0;
	public static final int ALPHA_LATE = 1;
	public static final int BETA = 2;
	public static final int R125 = 3;
	public static final int R125MP = 4;
	
	public static int level = SoftLock.ALPHA_EARLY;
	
	// Configurable GUI stuff. You may assign whatever level you need.
	
	public static int guiTitleType = SoftLock.level;
	public static int guiNewWorldType = SoftLock.level;
			
	// Genlayers are single biome (Alpha) for ALPHA_EARLY,
	// Ramp based biomes form ALPHA_LATE / BETA,
	// Normal genlayer for R125+.
	
	public static int genLayerLevel = SoftLock.level;
	
	// R125 options
	
	public static boolean colouredWater = false;
	public static boolean colouredFog = false;
	public static boolean doNoiseBasedChoices = false;
	
	public static String getVersionString() {
		switch (SoftLock.level) {
		case ALPHA_EARLY: return "Alpha v1.1.2";
		case ALPHA_LATE: return "Alpha v1.2.6";
		case BETA: return "Beta 1.7.3";
		case R125: return "1.2.5";
		case R125MP: return "1.2.6";
		default: return "Whatever";
		}
	}
	
	// These methods define some behaviours in the engine.
	// They are originally tied to softlock levels, but you can tweak as fit
	
	public static boolean hasNoiseTreeDensity() {
		return SoftLock.level < SoftLock.R125;
	}
	
	public static boolean hasEarlyAlphaTextures() {
		return SoftLock.level < SoftLock.BETA;
	}
	
	public static boolean hasReleaseStructures() {
		return SoftLock.level >= SoftLock.R125;
	}

	public static boolean useNewAIMobs() {
		return SoftLock.level >= SoftLock.R125;
	}
	
	public static boolean playerCanRun () {
		return SoftLock.level > SoftLock.BETA;
	}
	
	public static boolean playerHasHunger() {
		return SoftLock.level > SoftLock.BETA;
	}

	public static boolean useXP() {
		return SoftLock.level > SoftLock.BETA;
	}

	public static boolean canBreedAnimals() {
		return SoftLock.level > SoftLock.BETA;	
	}
	
	public static boolean modernBow() {
		return SoftLock.level > SoftLock.BETA;
	}

	public static boolean modernChests() {
		return SoftLock.level > SoftLock.BETA;
	}

	public static boolean hasSunriseSunset() {
		return SoftLock.level > SoftLock.ALPHA_LATE;
	}

	public static WorldType defaultWorldType() {
		// Change this as fit
		switch(SoftLock.level) {
		case SoftLock.ALPHA_EARLY:
			return WorldType.ALPHA;
		case SoftLock.ALPHA_LATE:
		case SoftLock.BETA:
			return WorldType.DEFAULT_1_1; // TODO :: CHANGE THIS 
		case SoftLock.R125:
		default:
			return WorldType.DEFAULT;
		}
	}
	
	public static WorldType defaultWorldType(boolean snowCovered) {
		switch(SoftLock.level) {
		case SoftLock.ALPHA_EARLY:
			return snowCovered ? WorldType.ALPHA_SNOW : WorldType.ALPHA;
		case SoftLock.ALPHA_LATE:
		case SoftLock.BETA:
			return WorldType.DEFAULT_1_1; // TODO :: CHANGE THIS 
		case SoftLock.R125:
		default:
			return WorldType.DEFAULT;
		}
	}

	public static GenLayer[] initializeAllBiomeGenerators(long seed, WorldType worldType) {
		// Change this as fit
		switch(SoftLock.level) {
		case SoftLock.ALPHA_EARLY:
			return GenLayerAlpha.initializeAllBiomeGenerators(seed, worldType);
		case SoftLock.ALPHA_LATE:
		case SoftLock.BETA:
			return GenLayer.initializeAllBiomeGenerators(seed, worldType); // TODO :: CHANGE THIS 
		case SoftLock.R125:
		default:
			return GenLayer.initializeAllBiomeGenerators(seed, worldType);
		}
	}

	public static boolean classicHurtSound() {
		return SoftLock.level < SoftLock.BETA;
	}

	public static boolean hasNether() {
		return SoftLock.level > SoftLock.ALPHA_EARLY;
	}

	public static boolean drawTooltips() {
		return SoftLock.level >= SoftLock.BETA;
	}

	public static boolean enableSquids() {
		return SoftLock.level >= SoftLock.BETA;
	}

	public static boolean enableEndermen() {
		return SoftLock.level > SoftLock.BETA;
	}

	public static WorldProvider getWorldProviderForSurface() {
		// Change as fit
		switch (SoftLock.level) {
		case SoftLock.ALPHA_EARLY:
		case SoftLock.ALPHA_LATE:
		case SoftLock.BETA:
			return new WorldProviderSurfaceClassic();
		case SoftLock.R125:
		case SoftLock.R125MP:
		default:
			return new WorldProviderSurface();
		}
	}

}
