package argo.jdom;

public interface JsonNodeBuilder {
	JsonNode buildNode();
}
