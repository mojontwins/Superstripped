package argo.jdom;

public class JsonNodeDoesNotMatchJsonNodeSelectorException extends IllegalArgumentException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 2619156457241613769L;

	JsonNodeDoesNotMatchJsonNodeSelectorException(String var1) {
		super(var1);
	}
}
