package argo.jdom;

public abstract class JsonRootNode extends JsonNode {
}
