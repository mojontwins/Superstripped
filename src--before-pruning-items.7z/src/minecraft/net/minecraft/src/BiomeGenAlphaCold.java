package net.minecraft.src;

public class BiomeGenAlphaCold extends BiomeGenAlpha {

	public BiomeGenAlphaCold(int i1) {
		super(i1);
		this.weather = Weather.cold;
	}

}
