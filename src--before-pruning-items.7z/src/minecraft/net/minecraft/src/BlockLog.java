package net.minecraft.src;

import java.util.List;
import java.util.Random;

public class BlockLog extends Block {
	
	public static final int OakMetadata = 0;
	public static final int SpruceMetadata = 1;
	public static final int BirchMetadata = 2;
	public static final int JungleMetadata = 3;
	
	protected BlockLog(int i1) {
		super(i1, Material.wood);
		this.blockIndexInTexture = 20;
		
		this.displayOnCreativeTab = CreativeTabs.tabBlock;
	}

	public int getRenderType() {
		return 31;
	}
	
	public int quantityDropped(Random random1) {
		return 1;
	}

	public int idDropped(int i1, Random random2, int i3) {
		return Block.wood.blockID;
	}

	public void harvestBlock(World world1, EntityPlayer entityPlayer2, int i3, int i4, int i5, int i6) {
		super.harvestBlock(world1, entityPlayer2, i3, i4, i5, i6);
	}

	public void onBlockRemoval(World world1, int i2, int i3, int i4) {
		byte b5 = 4;
		int i6 = b5 + 1;
		if(world1.checkChunksExist(i2 - i6, i3 - i6, i4 - i6, i2 + i6, i3 + i6, i4 + i6)) {
			for(int i7 = -b5; i7 <= b5; ++i7) {
				for(int i8 = -b5; i8 <= b5; ++i8) {
					for(int i9 = -b5; i9 <= b5; ++i9) {
						int i10 = world1.getBlockId(i2 + i7, i3 + i8, i4 + i9);
						if(i10 == Block.leaves.blockID) {
							int i11 = world1.getBlockMetadata(i2 + i7, i3 + i8, i4 + i9);
							if((i11 & 8) == 0) {
								world1.setBlockMetadata(i2 + i7, i3 + i8, i4 + i9, i11 | 8);
							}
						}
					}
				}
			}
		}

	}

	public void onBlockPlaced(World world, int x, int y, int z, int side) {
		// Make this compatible with beta wood types:
		int meta = world.getBlockMetadata(x, y, z);
		
		// Make horizontal & oriented?
		if (side > 1) {
			if(side == 2 || side == 3) meta |= 8;
			if(side == 4 || side == 5) meta |= 4;
		}
		
		world.setBlockMetadata(x, y, z, meta);
	}
	
	public int getBlockTextureFromSideAndMetadata(int side, int metadata) {
		int orientation = metadata & 12; 	
		int woodType = metadata & 3; 	
		
		if(
			(orientation == 0 && (side == 1 || side == 0)) ||
			(orientation == 4 && (side == 4 || side == 5)) ||
			(orientation == 8 && (side == 2 || side == 3))
		) {
			return 21;
		} else {
			switch(woodType) {
				case 1: return 116;
				case 2: return 117;
				case 3: return 153;
				default: return 20;
			}
		}
	}

	public int damageDropped(int i1) {
		return i1 & 3;
	}
	
	public void getSubBlocks(int par1, CreativeTabs par2CreativeTabs, List<ItemStack> par3List) {
		par3List.add(new ItemStack(par1, 1, 0));
		if(SoftLock.level < SoftLock.BETA) return;
		par3List.add(new ItemStack(par1, 1, 1));
		par3List.add(new ItemStack(par1, 1, 2));
		if(SoftLock.level < SoftLock.R125) return;
		par3List.add(new ItemStack(par1, 1, 3));
	}
}
