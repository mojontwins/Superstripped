package net.minecraft.src;

public interface IAnimals {
}
