package net.minecraft.src;

public class TextureOffset {
	public final int field_40734_a;
	public final int field_40733_b;

	public TextureOffset(int i1, int i2) {
		this.field_40734_a = i1;
		this.field_40733_b = i2;
	}
}
