package net.minecraft.src;

public class Version {

	public static String getVersion() {
		return SoftLock.getVersionString();
	}

}
