package net.minecraft.src;

public class BlockWood extends Block {
	public BlockWood(int i1) {
		super(i1, 4, Material.wood);
		
		this.displayOnCreativeTab = CreativeTabs.tabBlock;
	}

}
