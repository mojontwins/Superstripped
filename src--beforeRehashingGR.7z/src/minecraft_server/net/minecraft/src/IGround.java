package net.minecraft.src;

public interface IGround {

}
