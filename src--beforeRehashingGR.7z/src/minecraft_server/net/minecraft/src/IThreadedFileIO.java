package net.minecraft.src;

public interface IThreadedFileIO {
	boolean writeNextIO();
}
