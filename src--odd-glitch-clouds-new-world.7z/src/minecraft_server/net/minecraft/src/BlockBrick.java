package net.minecraft.src;

public class BlockBrick extends Block {

	public BlockBrick(int i1, int i2, Material material3) {
		super(i1, i2, material3);
	}

}
