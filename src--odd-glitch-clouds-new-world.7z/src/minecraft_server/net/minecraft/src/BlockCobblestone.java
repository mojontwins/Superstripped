package net.minecraft.src;

public class BlockCobblestone extends Block {

	protected BlockCobblestone(int i1, int i2, Material material3) {
		super(i1, i2, material3);
	}

}
