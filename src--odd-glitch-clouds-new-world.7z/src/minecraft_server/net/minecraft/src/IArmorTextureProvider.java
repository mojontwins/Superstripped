package net.minecraft.src;

public interface IArmorTextureProvider {
	String getArmorTextureFile(ItemStack var1);
}
