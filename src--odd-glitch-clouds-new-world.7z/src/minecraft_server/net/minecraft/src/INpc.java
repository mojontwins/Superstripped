package net.minecraft.src;

public interface INpc extends IAnimals {
}
