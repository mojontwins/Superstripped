package net.minecraft.src;

public interface IPlant {

}
