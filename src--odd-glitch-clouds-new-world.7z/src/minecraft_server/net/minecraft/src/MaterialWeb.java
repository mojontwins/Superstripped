package net.minecraft.src;

final class MaterialWeb extends Material {
	MaterialWeb() {
		super();
	}

	public boolean blocksMovement() {
		return false;
	}
}
