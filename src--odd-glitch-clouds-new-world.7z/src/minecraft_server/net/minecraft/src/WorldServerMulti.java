package net.minecraft.src;

import net.minecraft.server.MinecraftServer;

public class WorldServerMulti extends WorldServer {
	public WorldServerMulti(MinecraftServer minecraftServer1, ISaveHandler iSaveHandler2, String string3, int i4, WorldSettings worldSettings5, WorldServer worldServer6, WorldType worldType) {
		super(minecraftServer1, iSaveHandler2, string3, i4, worldSettings5, worldType);
	}
}
